optsp <- new.env()
optsp$deps <- 1e-8
